###################################
#        ToneZ V2.0.0             #
#       Retornz - 2023            #
###################################

Thank your for downloading ToneZ !


Here are the steps to install it :

1) Make your to have csound v6 installed on your computer

2) Copy the "Retornz" folder inside your $HOME directory

3) Finally copy the .so and/or .vst3 plugin where your host can find it

4) Enjoy & let us know how it goes on the Discord server :)
https://discord.com/invite/JyYqr4q

www.retornz.com
